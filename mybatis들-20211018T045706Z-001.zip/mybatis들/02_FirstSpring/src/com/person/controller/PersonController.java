package com.person.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.person.model.PersonDAOImpl;
import com.person.model.PersonVO;

@Controller
public class PersonController {
	@Autowired
	private PersonDAOImpl dao;
	//�߰���
  @RequestMapping(value="insert.go", method = RequestMethod.GET)
  public String insert() {
	  return "personForm";
  }
  //�߰�
  @RequestMapping(value = "insert.go", method = RequestMethod.POST)
  public String insert(PersonVO person) {
	 dao.person_insert(person);
	  return "redirect:list.go";
  }
  // ��ü����
  @RequestMapping("list.go")
  public ModelAndView list() {
	 List<PersonVO> userlist =  dao.person_list();  //list
	 int count =dao.person_count();
	 ModelAndView mv = new ModelAndView();
	 mv.addObject("count", count);
	 mv.addObject("userlist", userlist);
	 mv.setViewName("personList");
	  return  mv;
  }
  //�󼼺���
  @RequestMapping("view.go")
  public ModelAndView view(String id) {
	 PersonVO user= dao.person_view(id);
	 ModelAndView mv = new ModelAndView();
	 mv.addObject("user", user);
	 mv.setViewName("personView");
	  return mv; 
  }
  
  //������
  @RequestMapping("update.go")
  public ModelAndView update(String id) {
	  	PersonVO user= dao.person_view(id);
		 ModelAndView mv = new ModelAndView();
		 mv.addObject("person", user);
		 mv.setViewName("personUpdate");
		  return mv; 
  }
  //����
  @RequestMapping(value = "update.go", method = RequestMethod.POST)
  public String update(PersonVO person) {
	  dao.person_update(person);
	  return "redirect:list.go";
  }
  // ����
  @RequestMapping("delete.go")
  public String delete(String id) {
	  dao.person_delete(id);
	  return "redirect:list.go";
  }

  
}



