package com.myboard.mapper;

import com.myboard.dto.MemberDTO;

public interface MemberMapper {
	//�߰�
	 public void mInsert(MemberDTO member);
	//�󼼺���
	 public MemberDTO mfindById(String id);
	//����
	 public void mUpdate(MemberDTO member);
	//����
	 public void mDelete(String id);
	
}
