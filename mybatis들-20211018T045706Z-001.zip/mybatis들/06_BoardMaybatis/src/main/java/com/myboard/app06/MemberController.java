package com.myboard.app06;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myboard.dto.MemberDTO;
import com.myboard.model.MemberService;

@RequestMapping("/member/*")
@Controller
public class MemberController {
	@Autowired
	private MemberService mService;
	
	@GetMapping
	public String join() {
		return "member/join";
	}
	//�߰�
	 @PostMapping("join")
	 public String join(MemberDTO member) {
		 mService.insert(member);
		 return "member/login";
	 }
	 //�α����������� ����
	 @GetMapping("login")
	 public void login() {
		 
	 }
	 //�α��� üũ
	 @PostMapping("loginCheck")
	 @ResponseBody
	 public String login(HttpSession session, String id, String pass) {
 
		 String result="";
		  MemberDTO member =  mService.findById(id);
		  if(member==null) {//ȸ���ƴ�
			  result ="fail";
		  }else if(member.getPass().equals(pass)) { //ȸ����
			
			  //session.setAttribute("member", member);
			  session.setAttribute("sessId", id);
			  result ="success";
		  }else { // �������
			  result ="passfail";
		  }
		 return result;
	 }
	 
	 // �α׾ƿ�
	 @GetMapping("logout")
	 public String logout(HttpSession session) {
		 session.invalidate();
		 return "redirect:login";
	 }
	 //�����ϱ�
	 @GetMapping("view")
	 public String update(Model model, HttpSession session) {
		 String id = (String)session.getAttribute("sessId");
		 MemberDTO member = mService.findById(id);
		 model.addAttribute("member",member);
		return "member/update";
	 }
	  @GetMapping("idCheck")   	 //���̵�üũ �����ΰ���
	  public void idCheck() {	  }
	  //���̵� �ߺ�Ȯ��
	  @PostMapping("idCheck")
	  @ResponseBody
	  public String idCheck(String id) {
		 MemberDTO member =  mService.findById(id);
		 String result ="";
		 if(member==null)    result="success";
		 else  result="fail";
		  return result;
	  }
	  //Ż��
	  @GetMapping("delete")
	  public String delete(HttpSession session) {
		  String id = (String)session.getAttribute("sessId");
		  mService.delete(id);
		  session.invalidate();
		  return "redirect:login";
	  }
	  //����
	  @PutMapping("update")
	  @ResponseBody
	  public String update(@RequestBody MemberDTO member,HttpSession session) {
		  mService.update(member);
		//String id =  (String)session.getAttribute("sessId");
		session.invalidate();
	//	MemberDTO m  = mService.findById(id);
	//	session.setAttribute("sessId", m.getId());
	
		return "success";
	  }
	  //1. �����ϰ� �ٷ� �α׾ƿ� ==> �α��� â���� ������
	  //2 . �����ϰ� ���� ���� ���� ���� �ο��ϰ� ������ �����ִ� â���� ����
	

}
