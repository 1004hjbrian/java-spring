package com.myboard.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.myboard.dto.MemberDTO;
import com.myboard.mapper.MemberMapper;

@Repository
public class MemberDAOImpl  implements MemberDAO{
	@Autowired
	private MemberMapper memberMapper;

	@Override
	public void mdao_insert(MemberDTO member) {
		memberMapper.mInsert(member);
		
	}

	@Override
	public MemberDTO mdao_findById(String id) {
		return memberMapper.mfindById(id);
	}

	@Override
	public void mdao_update(MemberDTO member) {
	 memberMapper.mUpdate(member);
		
	}

	@Override
	public void mdao_delete(String id) {
	memberMapper.mDelete(id);
		
	}



}
