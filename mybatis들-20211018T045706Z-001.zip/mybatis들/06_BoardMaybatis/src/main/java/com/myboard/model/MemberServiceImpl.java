package com.myboard.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myboard.dto.MemberDTO;

@Service
public class MemberServiceImpl  implements MemberService{
	@Autowired
	private MemberDAO mdao;

	@Override
	public void insert(MemberDTO member) {
		mdao.mdao_insert(member);
	}

	@Override
	public MemberDTO findById(String id) {
			return mdao.mdao_findById(id);
	}

	@Override
	public void update(MemberDTO member) {
		mdao.mdao_update(member);
		
	}

	@Override
	public void delete(String id) {
		mdao.mdao_delete(id);
		
	}
  

}
