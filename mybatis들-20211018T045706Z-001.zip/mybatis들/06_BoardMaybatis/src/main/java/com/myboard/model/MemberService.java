package com.myboard.model;

import com.myboard.dto.MemberDTO;

public interface MemberService {
	//�߰�
	public void insert(MemberDTO member);
	//�󼼺���
	public MemberDTO findById(String id);
	//����
	public void update(MemberDTO member);
	//����
	public void delete(String id);


}
