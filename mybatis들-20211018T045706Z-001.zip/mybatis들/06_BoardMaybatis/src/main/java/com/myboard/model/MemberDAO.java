package com.myboard.model;

import com.myboard.dto.MemberDTO;

public interface MemberDAO {
	//�߰�
		public void mdao_insert(MemberDTO member);
		//�󼼺���
		public MemberDTO mdao_findById(String id);
		//����
		public void mdao_update(MemberDTO member);
		//����
		public void mdao_delete(String id);
	
}
