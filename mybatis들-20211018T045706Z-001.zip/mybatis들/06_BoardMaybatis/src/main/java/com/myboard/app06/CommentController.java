package com.myboard.app06;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.myboard.dto.CommentDTO;
import com.myboard.model.CommentService;
import com.myboard.model.CommentServiceImpl;

@RequestMapping("/reply/*")
@RestController  //@Controller + @ResponseBody
public class CommentController {
	
	@Autowired
	private CommentService cservice;
	
	//����߰�
	@PostMapping("commentInsert")
  public String insert(@RequestBody CommentDTO comment) {
		cservice.insert(comment);
		return "success";
	}
	
	//�����ü����
	@GetMapping("commentList")
	public List<CommentDTO> list(int num){
		List<CommentDTO> clist=cservice.getList(num);
		return clist;
	}
	//��ۻ���
	@DeleteMapping("del/{cnum}")
	public int delete(@PathVariable("cnum") int cnum) {
	    cservice.commentDelete(cnum);
	    return cnum;
	}
}





