package com.myspring.app03;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.myspring.model.MPersonDAOImpl;
import com.myspring.model.PersonDTO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired
	private MPersonDAOImpl dao;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	//�߰���
	//@RequestMapping("insert")
	@GetMapping("insert")
	public String insert() {
		return "personForm";
	}
	//�߰�
	//@RequestMapping(value = "insert", method =RequestMethod.POST)
	@PostMapping("insert")
	public String insert(PersonDTO person) {
		dao.per_insert(person);
		return "redirect:list";
	}
	//��ü����
	@GetMapping("list")
	public String list(Model model,String field, String word) {
		field=field==null?"":field;
		word=word==null?"":word;
		List<PersonDTO> userlist = dao.per_list(field, word);
		int count = dao.per_count(field, word);
		model.addAttribute("userlist", userlist);
		model.addAttribute("count", count);
		return "personList";
	}
	//�󼼺���, ������
	@GetMapping({"view", "update"})
	public void view(Model model,String id) {
		PersonDTO user = dao.per_view(id);
		model.addAttribute("user", user);
	}
	//����
	@PostMapping("update")
	public String update(PersonDTO person) {
		dao.per_update(person);
		return "redirect:list";
	}
	
	//����
	@GetMapping("delete")
	public String delete(String id) {
		dao.per_delete(id);
		return "redirect:list";
	}
	
	
}
