package com.myspring.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class MPersonDAOImpl  implements MPersonDAO{
	@Autowired
	private JdbcTemplate template;

	@Override
	public void per_insert(PersonDTO person) {
		String sql = "insert into person values(?,?,?,?,?)";
		Object[] param = new Object[] {
				person.getId(), person.getName(),
				person.getPassword(), person.getGender(),
				person.getJob()
		};
		template.update(sql,param); 	//spring jdbc Template
		
	}

	@Override
	public List<PersonDTO> per_list(String field, String word) {
		String sql ="";
		if(word.equals("")) {
			sql = "select * from person";
		}else {
			sql = "select * from person where "+ field + " like '%"+word+"%'";
		}
		List<PersonDTO> personlist 
		  = template.query(sql, new RowMapper<PersonDTO>() {
			  @Override
			public PersonDTO mapRow(ResultSet rs, int arg1) throws SQLException {
				PersonDTO user = new PersonDTO();
				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setGender(rs.getString("gender"));
				user.setJob(rs.getString("job"));
				return user;
			}
		 });
		return personlist;
	}
	

	@Override
	public PersonDTO per_view(String id) {
		String sql = "select * from person where id='"+id+"'";
		PersonDTO person 
		  = template.queryForObject(sql, new RowMapper<PersonDTO>() {
			  @Override
			public PersonDTO mapRow(ResultSet rs, int arg1) throws SQLException {
				PersonDTO user = new PersonDTO();
				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setGender(rs.getString("gender"));
				user.setJob(rs.getString("job"));
				return user;
			}
		 });
		return person;
	}
	

	@Override
	public void per_update(PersonDTO person) {
		String sql="update person  set name=?, job=?,password=? where id=?";
		Object[] param = new Object[] {
				person.getName(),
				person.getJob(),
				person.getPassword(),
				person.getId()
		};
		 template.update(sql,param);
	}
	@Override
	public void per_delete(String id) {
		String sql ="delete from person where id='"+id+"'";
		template.update(sql);
   }

	@Override
	public int per_count(String field, String word) {
		String sql ="";
		if(word.equals("")) {
			sql = "select count(*)  from person";
		}else {
			sql = "select count(*)  from person where "+ field + " like  '%"+word+"%'";
		}
		return template.queryForObject(sql, Integer.class);
	}

}





