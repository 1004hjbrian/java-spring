package com.myguest.app05;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myguest.model.GuestDTO;
import com.myguest.model.GuestListVO;
import com.myguest.model.GuestServiceImpl;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
@Autowired
	private GuestServiceImpl sevice;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "insert";
	}
	
	@PostMapping("gInsert")
	public String insert(@ModelAttribute GuestDTO guest,
			   HttpServletRequest request) {
		String ipaddr = request.getRemoteAddr();
		guest.setIpaddr(ipaddr);
		sevice.guestInsert(guest);
		return "redirect:gList";
	}
	
	/*@GetMapping("gList")
    public String list(Model model) {
		HashMap<String, String> hm = new HashMap<String, String>();
		List<GuestDTO> lists=sevice.list(hm);
		model .addAttribute("guestlist", lists);
		return "list";
	}*/
	
	@GetMapping("gList")
	@ResponseBody
	 public GuestListVO list(String field,String word) {
			HashMap<String, String> hm = new HashMap<String, String>();
		
			hm.put("field",field );
			hm.put("word",word );
			int count =sevice.countGuest(hm) ;
			List<GuestDTO> lists = sevice.list(hm);
	
			GuestListVO listvo = new GuestListVO(count, lists);
			return listvo;
		}
	
 /*
	@GetMapping("gView")
	@ResponseBody
	public String view(@RequestParam("num")  int num) {
		GuestDTO guest = sevice.findByNum(num);
		System.out.println("guest : " + guest);
       JSONObject obj = new JSONObject();
       obj.put("num",  guest.getNum());
       obj.put("name",  guest.getName());
       obj.put("content", guest.getContent());
       obj.put("grade", guest.getGrade());
       obj.put("created", guest.getCreated());
       obj.put("ipaddr", guest.getIpaddr());
		return obj.toString();
	}
	
	*/
	@GetMapping("gView")
	@ResponseBody
	public GuestDTO view(@RequestParam("num")  int num) {
		GuestDTO guest = sevice.findByNum(num);
		return guest;
	}
	
	//����
	@DeleteMapping("gDelete/{num}")
	@ResponseBody
	public String delete(@PathVariable int num) {
		sevice.guestDelete(num);
		return "success";
	}
	
	
}





