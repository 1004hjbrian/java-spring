package com.myguest.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;

import com.myguest.model.GuestDTO;

public interface GuestMapper {
	@Insert("insert into guestbook(name, content, grade, created, ipaddr) "
			+ " values(#{name}, #{content}, #{grade}, now(), #{ipaddr})")
	public void insert(GuestDTO guest);
	
	public List<GuestDTO> list(HashMap<String, String>hm);
	//�󼼺���
	public GuestDTO findByNum(int num);
	//����
	public int countGuest(HashMap<String, String> hm);
	//����
	@Delete("delete from guestbook where num=#{num}")
	public void delete(int num);
	
	

}
