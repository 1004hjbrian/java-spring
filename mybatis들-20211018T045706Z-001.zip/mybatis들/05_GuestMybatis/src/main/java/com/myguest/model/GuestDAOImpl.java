package com.myguest.model;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.myguest.mapper.GuestMapper;
@Repository
public class GuestDAOImpl  implements GuestDAO{
	@Autowired
	private GuestMapper mapper;

	@Override
	public void dao_guestInsert(GuestDTO guest) {
		 mapper.insert(guest);
		
	}

	@Override
	public List<GuestDTO> dao_list(HashMap<String, String> hm) {
		// TODO Auto-generated method stub
		return mapper.list(hm);
	}

	@Override
	public GuestDTO dao_findByNum(int num) {
		// TODO Auto-generated method stub
		return mapper.findByNum(num);
	}

	@Override
	public void dao_guestUpdate(GuestDTO guest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dao_guestDelete(int num) {
		mapper.delete(num);
		
	}

	@Override
	public int dao_countGuest(HashMap<String, String> hm) {
		return mapper.countGuest(hm);
	}

}
