package com.myspring.model;

import java.util.HashMap;
import java.util.List;

import com.myspring.vo.PersonVO;

public interface PersonService {
	//�߰�
	public void insert(PersonVO person);
	//��ü����
	public List<PersonVO> list(HashMap<String, String>hm);
	//�󼼺���
	public PersonVO view(String id);
	//����
	public void update(PersonVO person);
	//����
	public void delete(String id);
	//count
	public int count(HashMap<String, String>hm);
}
